
public class InitiateAlgorithm
{
	public static void main(String[] args)
	{
		CreateGraph createGraph = new CreateGraph();
		createGraph.acceprData();
		createGraph.algorithm();
	}
}
